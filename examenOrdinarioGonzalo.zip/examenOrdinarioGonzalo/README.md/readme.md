# Examen Ordinario -gonzalo santiago garcia

## Ejercicio 1: Vite + Vue.js
Contador interactivo usando Vue 3.

## Ejercicio 2: PHP + JavaScript
Formulario con validación de nombre, email y edad (cliente).

## Ejercicio 3: Node.js
Servidor HTTP básico que responde con un mensaje JSON en /api.
